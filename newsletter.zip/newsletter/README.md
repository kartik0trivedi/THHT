# THHT Newsletter Setup (Zoho Campaigns)

This template is designed to work with **Zoho Campaigns RSS-to-Email** automation. It matches the branding and minimalist aesthetic of your blog.

## 1. Prepare your Assets
- Upload the `newsletter/assets/logo.png` file to your **Zoho Campaigns Image Library**.
- Open `newsletter/template.html` in a text editor and replace the placeholder logo URL (`https://thht.in/logo.png`) with the URL from Zoho's library.

## 2. Create the RSS Campaign in Zoho
1. Login to **Zoho Campaigns**.
2. Go to **Automation** > **RSS Campaign** > **Create Campaign**.
3. **Draft Details**:
   - **Campaign Name**: Latest TH/HT Post
   - **RSS Feed URL**: `https://thht.in/rss.xml`
4. **Choose a Template**:
   - Select **Custom HTML** or **Import**.
   - Upload the modified `template.html` file.
5. **Campaign Settings**:
   - Set the check frequency (e.g., Daily or Weekly).
   - Because you have a **2-day delay** in your feed, Zoho will "discover" new posts 2 days after they are published on your site.

## 3. Mandatory Tags
This template includes the following mandatory merge tags for CAN-SPAM compliance:
- `$[LI:UNSUBSCRIBE]$`: The unsubscribe link.
- `$[LI:ADDRESS]$`: Your organization's physical address (required for Zoho Campaigns).
- `$[RSSITEMS:START:1]$` and `$[RSSITEMS:END]$`: The loop that displays exactly one post.

## 4. Testing
- Use Zoho's **Send Test Email** feature before launching the automation.
- Verify that the `$[RI:TITLE]$` and `$[RI:CONTENT]$` tags are replaced by your actual post content.

---
*Created with quiet persistence.*
